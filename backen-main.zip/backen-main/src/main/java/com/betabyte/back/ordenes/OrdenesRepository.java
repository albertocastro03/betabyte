package com.betabyte.back.ordenes;

import org.springframework.data.repository.CrudRepository;

public interface OrdenesRepository extends CrudRepository<OrdenesModel, Long> {


}
