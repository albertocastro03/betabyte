package com.betabyte.back.users;

public enum UserRole {
    client, admin, superadmin
}
