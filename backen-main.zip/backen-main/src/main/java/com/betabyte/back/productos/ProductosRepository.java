package com.betabyte.back.productos;

import org.springframework.data.repository.CrudRepository;

public interface ProductosRepository extends CrudRepository<ProductosModel, Long> {
    
}
