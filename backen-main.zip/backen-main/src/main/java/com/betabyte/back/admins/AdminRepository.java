package com.betabyte.back.admins;

import org.springframework.data.repository.CrudRepository;

public interface AdminRepository extends CrudRepository<AdminModel, Long> {

}
