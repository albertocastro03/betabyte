package com.betabyte.back.detallespedido;



import org.springframework.data.repository.CrudRepository;

public interface DetallesPedidosRepository extends CrudRepository<DetallesPedidosModel, Long> {

}
