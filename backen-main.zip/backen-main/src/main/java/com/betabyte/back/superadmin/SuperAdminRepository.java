package com.betabyte.back.superadmin;

import org.springframework.data.repository.CrudRepository;

public interface SuperAdminRepository extends CrudRepository<SuperAdminModel, Long> {
}
